from LassyExtraction.aethel import (Term, Var, Lex, Application, Abstraction,
                                    DiamondElim, DiamondIntro, BoxElim, BoxIntro,
                                    AxiomLinks, WordType, ProofFrame, PolarizedType, FunctorType)
from LassyExtraction.proofs import get_result, polarize_and_index
from typing import Tuple, Dict, Any


def term_to_axiom_links(term: Term, proof_frame: ProofFrame) -> AxiomLinks:
    vargen = iter(range(-500, -1))

    def lex_to_indexed_type(lex: Lex) -> WordType:
        return proof_frame.premises[lex.idx].type

    def var_to_indexed_type(var: Var) -> WordType:
        return polarize_and_index(var.t(), True, next(vargen))[1]

    def f(_term: Term) -> Tuple[AxiomLinks, WordType, Dict[int, WordType]]:
        if isinstance(_term, Var):
            vart = var_to_indexed_type(_term)
            return set(), vart, {_term.idx: vart}
        if isinstance(_term, Lex):
            return set(), lex_to_indexed_type(_term), dict()
        if isinstance(_term, Application):
            functor_links, functor_type, functor_vars = f(_term.functor)
            argument_links, argument_type, argument_vars = f(_term.argument)
            new_links = set()
            for fn_atom, arg_atom in zip(functor_type, argument_type):
                new_links.add((fn_atom.index, arg_atom.index) if fn_atom.polarity
                              else (arg_atom.index, fn_atom.index))
            return (argument_links.union(functor_links).union(new_links),
                    get_result(functor_type),
                    {**argument_vars, **functor_vars})
        if isinstance(_term, Abstraction):
            body_links, body_type, body_vars = f(_term.body)
            return (body_links,
                    FunctorType(body_vars[_term.abstraction.idx], body_type),
                    {k: v for k, v in body_vars.items() if k != _term.abstraction.idx})
        if isinstance(_term, (DiamondIntro, DiamondElim, BoxIntro, BoxElim)):
            return f(_term.body)
        raise Exception(f'Unknown term type: {type(_term)}')
    links, output, _ = f(term)
    links.add((output.index, proof_frame.conclusion.index))
    return links
